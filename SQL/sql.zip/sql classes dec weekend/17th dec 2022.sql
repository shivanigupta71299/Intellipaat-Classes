drop table flight

sp_help 'flight'

select * from student

insert into student values
(8,'Muskan',91,null,'','')
(6,'Nisha',89,null,null,null),
(7,'Nithin',90,null,null,null)

create table flight
(
	fid			varchar(10) ,
	starting	varchar(50),
	destination varchar(50) ,
	price		int check(price>0)
)

insert into flight values
('QA104','New york','Helsinki',-500)

('QA101','Doha','Tallinn',200),
('EM123','Mumbai','Dubai',220),
('IN111','Bengaluru','Chennai',50)


select * from flight



drop table flight

create table flight
(
	fid			varchar(10) primary key,
	starting	varchar(50),
	destination varchar(50) ,
	price		int 
)


insert into flight values
('QA104','New york','Helsinki',500),
('QA101','Doha','Tallinn',200),
('EM123','Mumbai','Dubai',220),
('IN111','Bengaluru','Chennai',50)


select * from flight

select * from student
select * from student_new

drop table passengers

create table passengers
(
	psid		int,
	psname		varchar(100),
	flightid	varchar(10) foreign key references flight(fid)
)



create table passengers
(
	psid		int,
	psname		varchar(100),
	flightid	varchar(10),
	constraint c5 foreign key(flightid)  references flight(fid)
)


insert into passengers values
(350,'Abhishek','ET999')
(123,'Sumana','IN111'),
(230,'Vanshika','QA101'),
(350,'Abhishek','ET999')


sp_help 'passengers'


select * from flight
select * from passengers

insert into passengers values
(999,'Pavan','EM123')

delete from flight where fid='IN111'




select * from student

alter table student
alter column roll int not null

alter table student
add constraint c1 primary key(roll)

select * from flight

insert into flight values
('','','' ,'')

sp_help 'flight'

create table train
(
	tid		int,
	tname	varchar(100),
	price	int check(price>=10)
)

insert into train values
(1,'Amritsar exp',100)


select count(*) from student	--8
select count(*) from student where age>=25	--2
select count(*) from student where age<25	--<=6

select * from student
