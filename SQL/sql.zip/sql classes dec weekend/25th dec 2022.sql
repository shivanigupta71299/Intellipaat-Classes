
select *,rank() over (order by marks desc) from student
select *,dense_rank() over (order by marks desc) from student
select *,row_number() over (order by marks desc) from student


select *,rank() over (order by age) from student
select *,dense_rank() over (order by age) from student
select *,row_number() over (order by age) from student


select * from student

select *,rank() over(partition by states order by marks desc) from student
select *,rank() over(partition by gender order by marks desc) from student


select *,dense_rank() over(partition by gender order by marks desc) from student
select *,dense_rank() over(order by marks desc) from student


select * from
(
	select *,row_number() over (partition by gender order by roll) as cnt
	from student
)t
order by cnt,gender



select * from
(
	select *,rank() over (partition by states order by marks desc) as cnt
	from student
)t
where cnt=1


--
select * from
(
select *,row_number() over(partition by roll order by roll) as cnt
from student
)t
where cnt>1

insert into student
select * from student where roll=3
select * from student

select *,rank() over(partition by states order by marks desc) from student
select *,rank() over(partition by gender order by marks desc) from student


select *,dense_rank() over(partition by gender order by marks desc) from student
select *,dense_rank() over(order by marks desc) from student


select * from
(
	select *,row_number() over (partition by gender order by roll) as cnt
	from student
)t
order by cnt,gender



select * from
(
	select *,rank() over (partition by states order by marks desc) as cnt
	from student
)t
where cnt=1


--
select * from
(
select *,row_number() over(partition by roll order by roll) as cnt
from student
)t
where cnt>1

insert into student
select * from student where roll=3


-- table vlued function

create function dbo.pplFrom(@s varchar(2))
returns table
as
	return 
		select * from student where states=@s


select * from dbo.pplFrom('DL')



select * from student


create procedure ripu
as

begin tran
begin try
	update student set marks=93 where roll=52
	
	waitfor delay '00:00:20'
	
	insert into student(roll,sname,marks)  values
	(53,'HArishkumar',96)

	commit
end try
begin catch
	rollback
end catch



begin tran
	insert into student(roll,sname,marks)  values
	(52,'Prashant',83)
	waitfor delay '00:00:10'
commit

select * from student



select * from student(nolock)

exec ripu




create table descr
(
	col1 int,
	col2 bigint,
	col3 tinyint,
	col4 smallint,
	col5 varchar(50),
	col6 nvarchar(50),
	col7 char(50),
	col8 varchar(max),
	col9 varchar,
	col10 datetime,
	col11 smalldatetime,
	col12 date,
	col13 float,
	col14 decimal(5,2),
	col15 numeric(5,2)
)

insert into descr(col4) values (1111100000)

insert into descr(col5,col6,col7) values
('siddhi','siddhi','siddhi')


insert into descr(col8) values
('siddhsdjghsljghjslfhgsfhglsfhshgsfhgwirwitpwtwpit494-4-tjdks')

insert into descr(col9) values
('s')


select * from descr

'siddhi'
'siddhi'
'siddhi'


insert into descr (col10,col11) values
('2022-12-25 22:58:29.883','2022-12-25 22:58:29.883')

insert into descr (col12) values
('2022-12-25 22:58:29.883')


insert into descr (col13,col14,col15) values
('29.88312343','29.88312343','29.88312343')


select getdate()