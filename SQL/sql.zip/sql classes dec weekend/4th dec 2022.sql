
create database intl_dec_weekend

drop database intl_aug_weekend

drop table student

create table student
(
	roll		int,	--whole number 0,1,-1,2,100
	sname		varchar(100),
	marks		numeric(5,2),
	age			int,
	gender		varchar(1),
	states		varchar(2)
)

insert into student values
(1,'Adarsh',82.53756563,25,'M','DL'),
(2,'Dipali',85.5,27,'F','CA'),
(3,'Ravindra',90,27,'M','DL'),
(4,'Priyanka',90,23,'F','WB'),
(5,'Sanket',92,24,'M','WB')





select * from student

SeleCT * FROM stUDent

--8 starting syntax (initial)



-- syntax  1		-- selecting the columns
select * from student
select roll,sname,marks from student

-- syntax 2 -- selecting rows
select * from student where roll>=3
select * from student where roll>3
select * from student where roll<3
select * from student where roll<=3
select * from student where roll=3
select * from student where roll!=3
select * from student where roll<>3

select * from student where roll<>3 and states='WB'

select * from student where roll<>3 or states='DL'

-- i need all the students from DL and WB

select * from student where states='DL' or states='WB'

-- i need all other students apart from DL and WB

select * from student where states <>'DL' and states <>'WB'


-- syntax 3  IN operator

select * from student where states in ('DL','WB')
select * from student where states not in ('DL','WB')

-- syntax 4 rearrange /reorder

select * from student order by age
select * from student order by age asc
select * from student order by age desc
select * from student order by age desc,marks desc

select * from student order by marks desc


select * from student order by gender

select * from student order by gender,marks
select * from student order by sname
select * from student order by sname desc
-- syntax 5 top
select top 1 * from student order by marks desc
select top 2 * from student order by marks desc
select top 1 sname from student order by marks desc

select top 1 with ties * from student order by age desc


select * from student

-- syntax 6  -- distinct/unique

select states,sname from student
select distinct states,sname from student

select distinct states from student

-- syntax 7 -- aggt functions

select max(marks) from student
select min(marks) from student
select avg(marks) from student
select sum(marks) from student

select max(marks),min(marks),avg(marks) from student


select avg(marks) from student where gender='M' and age>=25


-- select *,max(marks) from student --error





select max(marks) from student where gender='M' and age>=25

-- syntax 8			wildcard/regular exp

select * from student where sname like '%e%'
select * from student where sname like '%i%'

select * from student where sname like '___i%'


select * from student where sname like '%i'
select * from student where sname like 'a%'

