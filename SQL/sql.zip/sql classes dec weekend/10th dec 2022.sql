select * from student


create table student_new
(
	roll			int,
	student_name	varchar(100),
	score			numeric(5,2),
	emailid			varchar(200)
)

insert into student_new values
(1,'Akash',91,'akashmane123@gmail.com'),
(2,'Bindu',88.3,'bindu123@yahoo.com'),
(3,'Darshit',87,null),
(100,'Jyothi',85,null),
(101,'Manoj',83,null)


select * from student_new

insert into student_new(student_name,score,roll) values
('Nisha',87.4,102)



select * from student
select * from student_new 

select roll from student
union all
select roll from student_new


select roll from student
union 
select roll from student_new

select roll from student
intersect 
select roll from student_new

select roll from student
except 
select roll from student_new

select roll from student_new
except 
select roll from student


select age,sname from student
union
select roll,student_name from student_new


select roll,sname from student

select roll,student_name from student_new



select * from 
(
	select roll,sname from student
	union
	select roll,student_name from student_new
)t
where sname like '%a%'
order by roll desc

select * into abubakar from 
(
	select roll,sname from student
	union
	select roll,student_name from student_new
)t


select * from abubakar


select roll,student_name into harish from student_new 
where score<=90
order by student_name desc


select * from harish order by student_name desc




select * from student 
select * from student_new


select * from student where roll in (1,2,3,100,101,102)

select * from student where roll in 
(select roll from student_new where roll>=50 and roll<=101)

select * from student where roll>=(..) and roll<=(....)

select * from student where roll>=2 and roll<=4


select * from student where marks>  (select marks from student where roll=3)

select * from student where marks>  (select avg(marks) from student)




select top 1 * from
(
	select top 3 * from student_new order by score desc
)t
order by score asc

select * from student where roll>=2 and roll<=4

select * from student where roll between 2 and 4



select states,avg(marks) from student group by states

select states,avg(marks) from student where roll!=5
group by states
having avg(marks)>=86

select avg(marks) from student where roll!=5
group by states


select states,avg(marks) from student group by states





select states,avg(marks) from student where roll!=5
group by states
having avg(marks)>=86

select * from 
(
	select states,avg(marks) as avrg from student where roll!=5
	group by states
)t
where avrg>=86



select states,sname,max(marks) from student
group by states


select states,avg(marks) from student
group by states

select gender,avg(marks) from student
group by gender

select states,gender,avg(marks) from student
group by states,gender


select states,gender,avg(marks) from student
group by states,gender
order by avg(marks)



select roll,sname,marks into siddhant from student where roll!=5


select roll,sname,marks into #siddhi from student where roll!=5
select roll,sname,marks into ##siddhi from student where roll!=5



select * from #siddhi
select * from ##siddhi

select * from #siddhi

select * from ##siddhi



