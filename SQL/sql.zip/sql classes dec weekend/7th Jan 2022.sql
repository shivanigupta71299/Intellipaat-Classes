select * from student 

select * into harish from 
(
	select * from student
)t
pivot
(
	avg(marks) for subjects in([phys],[chem],[math])
)p



select *,cast(phys as numeric(5,2)) from harish

select *,'hi '+cast(roll as varchar(10)) from harish





select *,stuff(sname,len(sname)/2,3,'***') from student

select *,len(sname)/2 from student


select * from bw.dbo.harish

select * from student 

create clustered index ind1 on student(roll)
create nonclustered index ind2 on student(sname)



select * from inserted
select * from deleted


create trigger t1
on student
after insert,delete,update
as
begin
	select * from inserted
	select * from deleted
end


select * from student

select * from student_bkp


insert into student(roll,sname,marks) values
(100,'sumana',100)

delete from student where roll=5


update student set marks=99 where roll=6




select * into student_bkp from student where 1=0

select * from student_bkp


create trigger t2
on student
after delete
as
begin
	insert into student_bkp
	select * from deleted
end


select * from student


create trigger t3
on student
instead of delete
as
begin
	declare @r	int
	declare @a  int
	select @r=roll from deleted
	select @a=age from deleted
	if(@a is null)
	begin
		delete from student where roll=@r
	end
end

select * from student

delete from student where roll=7