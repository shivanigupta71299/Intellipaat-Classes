select *,left(sname,1) from student
select *,left(sname,2) from student
select *,right(sname,3) from student
select *,substring(sname,2,4) from student
select *,replace(sname,'a','x') from student
select *,len(sname) from student
select *,reverse(sname) from student
select *,charindex('a',sname) from student
select *,stuff(sname,2,3,'abc') from student
select *,upper(sname),lower(sname) from student



select *,charindex('a',sname)+charindex('a',substring(sname,charindex('a',sname)+1,len(sname)))
from student



select *,len(sname)-len(replace(sname,'a','')) from student


select roll,sname,marks,roll+4 as mroll,roll-1 as nroll 
from student


select * from student


alter table student
add doj datetime

update student 
set doj='2021-02-25 14:20:00.000'
where roll=5

select getdate()


select *,datediff(day,doj,getdate()) from student
select *,datediff(MONTH,doj,getdate()) from student
select *,datediff(year,doj,getdate()) from student

select *,datediff(year,doj,getdate())
,datediff(month,doj,getdate())
,datediff(day,doj,getdate())
from student

select *,day(doj),month(doj),year(doj) from student

select *,dateadd(day,100,doj) from student

select dateadd(day,100,getdate())

select *,datename(weekday,doj),datepart(weekday,doj) from student


student


alter table student
alter column doj datetime



select *,cast(doj as datetime) from student

select *,convert(datetime,doj ) from student


select *,convert(varchar(30),doj,105) from student





create function atul(@s	varchar(100),@c varchar(1))
returns int
as
begin
	declare @count int

	set @count=len(@s)-len(replace(@s,@c,'')) 

	return @count
end



declare @a int
declare @b int
declare @c int

set @a=10
set @b=5

set @c=@a+@b

print(@c)



select *,dbo.atul(sname,'a') from student

select *,dbo.atul(starting,'u') from flight




create function isLeapYear(@d datetime)
returns varchar(3)
as
begin
	declare @res varchar(3)
	declare @y int
	set @y=year(@d)

	if( (@y%400=0) or (@y%4=0 and @y%100!=0))
		set @res='yes'
	else

		set @res='no'

	return @res
end






select dbo.isLeapYear('2000-12-24 22:54:15.177')

