

select * from student --where roll>=4 and roll<=7

select * from student_new

select * from student 
where roll between 4 and 7

select* from amazon

delete from amazon where roll=''






select* from amazon
select* from student

create procedure weekday_1230
as
update s
set s.sname=a.student_name,
	s.marks=a.score
from student s inner join amazon a
on s.roll=a.roll

insert into student(roll,sname,marks)
select a.* from student s right join amazon a
on s.roll=a.roll
where s.roll is null

truncate table amazon





exec weekday_1230




create procedure studentFrom @s varchar(2)
as
select * from student where states=@s


exec studentFrom 'DL'





merge student s
using amazon a
on s.roll=a.roll
when matched then update
set s.sname=a.student_name,
	s.marks=a.score
when not matched then insert(roll,sname,marks)
	values(a.roll,a.student_name,a.score)



select * from orders		-- fact		measure		transactional
select * from product		-- dimension	master
select * from users			-- dimension	master

create view levis_sales
as
select o.oid,u.uname,p.pname,p.price*o.qty as bill
from orders as o
inner join users as u
on o.usid=u.userid
inner join product as p
on o.pid=p.pid


select * from levis_sales


delete from levis_sales where oid=10000


select * from student

create view vraj
as
select roll,sname,marks from student where states='DL' 

drop view vraj

select * from vraj

delete from vraj where roll=1

insert into vraj values
(30,'Shamreedh',89),
(31,'Guha',30)


select *,isnull(isnull(age,marks),0) from student

select *,coalesce(age,marks,roll,0) from student
