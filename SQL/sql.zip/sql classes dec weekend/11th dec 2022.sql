

select roll,sname,marks
into ##parth
from student
where roll>1

select * from #parth
select * from ##parth

select * from abubakar



create table student_hobby
(
	roll		int,
	interest	varchar(20),
)

select * from student
insert into student_hobby values
(1,'football'),
(2,'travelling'),
(3,'teaching'),
(50,'singing'),
(51,'cooking')


select * from student
select * from student_hobby

select roll,sname from student
union
select roll,interest from student_hobby



-- cartesian product
select * from student,student_hobby
where student.roll=student_hobby.roll

-- join
select * from student inner join student_hobby
on student.roll=student_hobby.roll

select * from student join student_hobby
on student.roll=student_hobby.roll


select s.*,h.interest 
from student as s inner join student_hobby as h
on s.roll=h.roll


select *
from student as s left join student_hobby as h
on s.roll=h.roll

select *
from student as s right join student_hobby as h
on s.roll=h.roll

select *
from student as s full outer join student_hobby as h
on s.roll=h.roll


select *
from student as s left join student_hobby as h
on s.roll=h.roll
where h.roll is null

select s.states,s.sname from student as s
inner join
(
	select states,avg(marks) as highest from student group by states
)t
on s.states=t.states and s.marks=t.highest


select states,max(marks) as highest into #darshit from student group by states

select s.states,s.sname from student as s
inner join #darshit t
on s.states=t.states and s.marks=t.highest


select * from student 

select states,max(marks) as highest from student group by states




select * from abubakar

delete from abubakar where roll=1

drop table abubakar


select * from student


update student
set marks=marks+3,
	age=age-1
where roll in (1,2)

update student
set marks=marks+3
where roll in (1,2)

update student 
set marks=90
where roll=1

alter table student
add emailid varchar(100)

alter table student
alter column emailid int

alter table student
drop column emailid

sp_help 'student'



select  * into sumana1 from student
select  * into sumana2 from student

select * from sumana1
select * from sumana2

truncate table sumana1
delete from sumana2


drop table movie

create table movie
(
	mid		int	identity(100,5),
	mname	varchar(100)
)

insert into movie values
('Sholay'),
('Godfather'),
('Avengers'),
('Batman'),
('Titanic')

select * from movie

truncate table movie
delete from movie





drop table flight

create table flight
(
	fid			varchar(10) primary key,
	starting	varchar(50) unique,
	destination varchar(50) unique,
	price		int
)



create table flight
(
	fid			varchar(10),
	starting	varchar(50) unique,
	destination varchar(50) unique,
	price		int,
	primary key(fid)
)


insert into flight values
('QA104',null,'Helsinki',200)

('QA101','Doha','Tallinn',200),
('EM123','Mumbai','Dubai',220),
('IN111','Bengaluru','Chennai',50)


select * from flight


sp_help 'flight'