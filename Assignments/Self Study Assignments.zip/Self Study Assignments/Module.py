#!/usr/bin/env python
# coding: utf-8

# In[1]:


def addition(num1, num2):
    return num1 + num2

def subtraction(num1, num2):
    return num1 - num2

def multiplication(num1, num2):
    return num1 * num2

def division(num1, num2):
    if num2 != 0:
        return num1 / num2
    else:
        print("Error: Division by zero is not allowed.")


# In[ ]:




